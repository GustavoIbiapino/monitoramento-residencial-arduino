const int pir = 2;
const int ledVerde = 12;
const int ledVermelho = 13;
const int buzzer = 8;

int estadoAnterior = LOW;

void setup() {
  pinMode(pir, INPUT);
  pinMode(ledVerde, OUTPUT);
  pinMode(ledVermelho, OUTPUT);
  pinMode(buzzer, OUTPUT);

  Serial.begin(9600);
  Serial.println("Sistema de monitoramento iniciado.");
}

void loop() {
  int movimento = digitalRead(pir);

  if (movimento == HIGH) {
    digitalWrite(ledVermelho, HIGH);
    digitalWrite(ledVerde, LOW);
    tone(buzzer, 1000);

    if (estadoAnterior == LOW) {
      Serial.println("ALERTA: Movimento detectado! Nivel de risco: ALTO");
    }
  } else {
    digitalWrite(ledVermelho, LOW);
    digitalWrite(ledVerde, HIGH);
    noTone(buzzer);

    if (estadoAnterior == HIGH) {
      Serial.println("Ambiente seguro. Nivel de risco: BAIXO");
    }
  }

  estadoAnterior = movimento;
  delay(300);
}